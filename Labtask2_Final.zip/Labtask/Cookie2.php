<?php
// Show cookie data if available
if(isset($_COOKIE["username"]) && isset($_COOKIE["email"])) {
    echo "<h2>Cookie Data</h2>";
    echo "Name: " . htmlspecialchars($_COOKIE["username"]) . "<br>";
    echo "Email: " . htmlspecialchars($_COOKIE["email"]) . "<br>";
} else {
    echo "No cookie data found.<br>";
    echo '<a href="index.html">Go to Form</a>';
}
?>