<?php
// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
 
    // Simple validation
    if (!empty($username) && !empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Set cookies for 1 hour
        setcookie("username", $username, time() + 3600, "/");
        setcookie("email", $email, time() + 3600, "/");
 
        echo "Cookie has been set successfully! <br>";
        echo '<a href="cookie2.php">Go to Cookie Page</a>';
    } else {
        echo "Invalid input. Please go back and try again.<br>";
        echo '<a href="index.html">Back to Form</a>';
    }
} else {
    echo "No data submitted.";
}
?>
 